# testgithub git init git add README.md git commit -m first commit git remote add origin https://github.com/bppwd/testgithub.git git push -u origin master
# testgithub
