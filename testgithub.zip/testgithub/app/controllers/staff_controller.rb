class StaffController < ApplicationController
  def index
  end
end
