class SiteController < ApplicationController
  def index
  end
end
