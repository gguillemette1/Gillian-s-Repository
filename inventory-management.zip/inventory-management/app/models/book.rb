class Book < ActiveRecord::Base
end
