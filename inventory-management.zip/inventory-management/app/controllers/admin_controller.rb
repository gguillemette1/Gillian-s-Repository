class AdminController < ApplicationController
  def index
  end
end
